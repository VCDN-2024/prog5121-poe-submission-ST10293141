
package prog_poe_part3_kaedon_naidoo_st10293141;
import javax.swing.JOptionPane;

public class Login {
    // Declaration of public variables
    public String LogUsername = "";
    public String LogPassword = "";

    // A method that allows the user to input their username to login
    public void checkLoginUsername() {
        JOptionPane.showMessageDialog(null, "Registration is finished, please log in");

        // Loop until a non-empty username is provided
        while (LogUsername.trim().isEmpty()) {
            LogUsername = JOptionPane.showInputDialog("Please enter your username: ");
            if(LogUsername == null) {
                // User clicked 'Cancel'
                // Handle the situation, either exit the program or provide feedback
                // For example:
                JOptionPane.showMessageDialog(null, "You need to provide a username to log in.");
            }
        }
    }

    // A method that allows the user to input their password to login
    public void checkLoginPassword() {
        // Loop until a non-empty password is provided
        while (LogPassword.trim().isEmpty()) {
            LogPassword = JOptionPane.showInputDialog("Please enter your password: ");
            if(LogPassword == null) {
                // User clicked 'Cancel'
                // Handle the situation, either exit the program or provide feedback
                // For example:
                JOptionPane.showMessageDialog(null, "You need to provide a password to log in.");
            }
        }
    }
    

    // Method to validate the login credentials
    public boolean validateLogin(String RegUsername, String RegPassword) {
        if (LogUsername.equals(RegUsername) && LogPassword.equals(RegPassword)) {
            System.out.println("Login Successful");
            return true;
        } else {
            System.out.println("Login Failed. Incorrect username or password.");
            return false;
        }
    }

   
}

//Reference For The Code:
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160786-dt-content-rid-120712113_1/xid-120712113_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160787-dt-content-rid-120712115_1/xid-120712115_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160788-dt-content-rid-120712114_1/xid-120712114_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160789-dt-content-rid-120712117_1/xid-120712117_1