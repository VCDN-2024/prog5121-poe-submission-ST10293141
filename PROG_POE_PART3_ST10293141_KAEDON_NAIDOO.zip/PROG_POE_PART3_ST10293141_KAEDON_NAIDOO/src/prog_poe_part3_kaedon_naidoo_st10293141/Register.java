
package prog_poe_part3_kaedon_naidoo_st10293141;
import javax.swing.JOptionPane;

public class Register {
     // Declaration of public variable
     public String username;
     public String password;
     public String name;
     public String surname;
    
    
    // A method which allows users to input their username and checks whether the entered username follows the criteria
    public String checkUsername(){
        boolean valid = false;
       
        while(!valid || username.isEmpty()){
             username = JOptionPane.showInputDialog("Please enter a 5 character long username which contains an underscore: ");
             username = this.username;
             
             if(username.length() <= 6 && username.contains("_")){
                 JOptionPane.showMessageDialog(null,"Username successfully captured");
                 valid = true;
             }
             else{
                 JOptionPane.showMessageDialog(null,"Username is not correctly formatted, please ensure that you username "
                         + "contains an underscore and is no more than 5 charcters in length");
                 
             }    
        }
        return username;
    }
    
    // A method which allows users to input their password and checks whether the entered password follows the criteria
    public String checkPassword() {
        String CHAR = "!@#$%^&*()_-+={}[]:;<>,.?/";

        boolean valid = false;

        while (!valid || password == null) {
            password = JOptionPane.showInputDialog("Please enter an 8 character password which contains a capital letter, a number, and a special character: ");

            if (password.length() >= 8 && password.matches(".*[A-Z].*") && password.matches(".*\\d.*")) {
                // A for loop which checks whether the entered password contains a special character by checking all the characters that are not letters and numbers
                boolean hasSpecialChar = false;
                for (int i = 0; i < password.length(); i++) {
                    if (CHAR.contains(Character.toString(password.charAt(i)))) {
                        hasSpecialChar = true;
                        break;
                    }
                }

                if (hasSpecialChar) {
                    JOptionPane.showMessageDialog(null, "Password successfully captured");
                    valid = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character");
            }
        }
        return password;
    }
    
    // A method which allows user to input their first and last name
    public void Credentials(){
        name = JOptionPane.showInputDialog("Please enter your first name: ");
        surname = JOptionPane.showInputDialog("Please enter your last name: ");
    }
}

//Reference For The Code:
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160786-dt-content-rid-120712113_1/xid-120712113_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160787-dt-content-rid-120712115_1/xid-120712115_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160788-dt-content-rid-120712114_1/xid-120712114_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160789-dt-content-rid-120712117_1/xid-120712117_1