
package prog_poe_part3_kaedon_naidoo_st10293141;

import javax.swing.JOptionPane;
import java.util.ArrayList;

public class prog_poe_part3_kaedon_naidoo_st10293141 {

    public static void main(String[] args) {
        Register u = new Register();
        u.Credentials();
        u.checkUsername();
        u.checkPassword();

        Login l = new Login();
        l.checkLoginUsername();
        l.checkLoginPassword();

        String RegUsername = u.username;
        String RegPassword = u.password;
        String firstname = u.name;
        String lastname = u.surname;

        String LoginUsername = l.LogUsername;
        String LoginPassword = l.LogPassword;

        boolean check = false;
        while (!check || LoginUsername.isEmpty() || LoginPassword.isEmpty()) {
            if (RegUsername.equals(LoginUsername) && RegPassword.equals(LoginPassword)) {
                JOptionPane.showMessageDialog(null, "Hello " + firstname + " " + lastname + "\nGood to see you again");
                check = true;
            } else {
                JOptionPane.showMessageDialog(null, "Username or Password incorrect, please try again");
                l.checkLoginUsername();
                l.checkLoginPassword();
                LoginUsername = l.LogUsername;
                LoginPassword = l.LogPassword;
                check = false;
            }
        }

        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");

        ArrayList<Task> tasks = new ArrayList<>();
        ArrayList<String> developers = new ArrayList<>();
        ArrayList<String> taskNames = new ArrayList<>();
        ArrayList<String> taskIDs = new ArrayList<>();
        ArrayList<Integer> taskDurations = new ArrayList<>();
        ArrayList<String> taskStatuses = new ArrayList<>();

        // Sample Data
        String[][] sampleData = {
                {"Mike Smith", "Create Login", "5", "To Do"},
                {"Edward Harrison", "Create Add Features", "8", "Doing"},
                {"Samantha Paulson", "Create Reports", "2", "Done"},
                {"Glenda Oberholzer", "Add Arrays", "11", "To Do"}
        };

        for (String[] data : sampleData) {
            Task task = new Task(data[1], "Sample description", data[0], Integer.parseInt(data[2]), tasks.size());
            task.setTaskStatus(data[3]);
            tasks.add(task);
            developers.add(data[0]);
            taskNames.add(data[1]);
            taskIDs.add(task.getTaskID());
            taskDurations.add(task.getTaskDuration());
            taskStatuses.add(data[3]);
        }

        displayTasksWithStatusDone(developers, taskNames, taskDurations, taskStatuses);
        displayTaskWithLongestDuration(developers, taskDurations);
        searchTaskByName(tasks, "Create Login");
        searchTasksByDeveloper(tasks, "Samantha Paulson");
        deleteTaskByName(tasks, developers, taskNames, taskIDs, taskDurations, taskStatuses, "Create Reports");
        displayReport(tasks);
    }

    public static void displayTasksWithStatusDone(ArrayList<String> developers, ArrayList<String> taskNames, ArrayList<Integer> taskDurations, ArrayList<String> taskStatuses) {
        StringBuilder result = new StringBuilder("Tasks with status 'Done':\n");
        for (int i = 0; i < taskStatuses.size(); i++) {
            if (taskStatuses.get(i).equalsIgnoreCase("Done")) {
                result.append("Developer: ").append(developers.get(i)).append(", Task Name: ").append(taskNames.get(i)).append(", Task Duration: ").append(taskDurations.get(i)).append(" hours\n");
            }
        }
        JOptionPane.showMessageDialog(null, result.toString());
    }

    public static void displayTaskWithLongestDuration(ArrayList<String> developers, ArrayList<Integer> taskDurations) {
        int maxDuration = 0;
        int index = -1;
        for (int i = 0; i < taskDurations.size(); i++) {
            if (taskDurations.get(i) > maxDuration) {
                maxDuration = taskDurations.get(i);
                index = i;
            }
        }
        JOptionPane.showMessageDialog(null, "Developer with the longest task duration: " + developers.get(index) + ", Duration: " + maxDuration + " hours");
    }

    public static void searchTaskByName(ArrayList<Task> tasks, String taskName) {
        for (Task task : tasks) {
            if (task.getTaskName().equalsIgnoreCase(taskName)) {
                JOptionPane.showMessageDialog(null, "Task Found: \n" + task.printTaskDetails());
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found");
    }

    public static void searchTasksByDeveloper(ArrayList<Task> tasks, String developerName) {
        StringBuilder result = new StringBuilder("Tasks assigned to " + developerName + ":\n");
        for (Task task : tasks) {
            if (task.getDeveloperDetails().equalsIgnoreCase(developerName)) {
                result.append("Task Name: ").append(task.getTaskName()).append(", Task Status: ").append(task.getTaskStatus()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, result.toString());
    }

    public static void deleteTaskByName(ArrayList<Task> tasks, ArrayList<String> developers, ArrayList<String> taskNames, ArrayList<String> taskIDs, ArrayList<Integer> taskDurations, ArrayList<String> taskStatuses, String taskName) {
        for (int i = 0; i < tasks.size(); i++) {
            if (tasks.get(i).getTaskName().equalsIgnoreCase(taskName)) {
                tasks.remove(i);
                developers.remove(i);
                taskNames.remove(i);
                taskIDs.remove(i);
                taskDurations.remove(i);
                taskStatuses.remove(i);
                JOptionPane.showMessageDialog(null, "Task '" + taskName + "' successfully deleted");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found");
    }

    public static void displayReport(ArrayList<Task> tasks) {
        StringBuilder report = new StringBuilder("All Tasks Report:\n");
        for (Task task : tasks) {
            report.append(task.printTaskDetails()).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, report.toString());
    }
}

//Reference For The Code:
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160786-dt-content-rid-120712113_1/xid-120712113_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160787-dt-content-rid-120712115_1/xid-120712115_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160788-dt-content-rid-120712114_1/xid-120712114_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160789-dt-content-rid-120712117_1/xid-120712117_1