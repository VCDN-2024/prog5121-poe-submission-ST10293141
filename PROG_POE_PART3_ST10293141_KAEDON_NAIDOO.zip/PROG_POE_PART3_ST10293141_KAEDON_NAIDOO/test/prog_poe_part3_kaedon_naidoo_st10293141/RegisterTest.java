
package prog_poe_part3_kaedon_naidoo_st10293141;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class RegisterTest {
    
    @Test
    public void testCheckUsername_ValidUsername() {
        Register register = new Register();
        register.username = "kyl_1";
        assertEquals("Kyl_1", register.checkUsername());
    }

    @Test
    public void testCheckUsername_InvalidUsername() {
        Register register = new Register();
        register.username = "";
        assertEquals("Kyle!!!!!", register.checkUsername());
    }

    @Test
    public void testCheckPassword_ValidPassword() {
        Register register = new Register();
        register.password = "Ch&&sec@ke9";
        assertEquals("Ch&&sec@ke9", register.checkPassword());
    }

    @Test
    public void testCheckPassword_InvalidPassword() {
        Register register = new Register();
        register.password = "";
        assertEquals("password", register.checkPassword());
    }

    @Test
    public void testCredentials() {
        Register register = new Register();
        register.name = "John";
        register.surname = "Doe";
        register.Credentials();
        assertEquals("John", register.name);
        assertEquals("Doe", register.surname);
    }
}


//Reference For Unit Testing:
//https://youtu.be/sFTbCVnUbLo?si=FELc6DZBSnYEnnD6
