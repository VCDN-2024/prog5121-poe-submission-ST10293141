
package prog_poe_part3_kaedon_naidoo_st10293141;

import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;

public class TaskTest {

    @Test
    public void testCheckTaskDescription() {
        Task task = new Task("TaskName", "Short description", "Developer", 10, 1);
        assertTrue(task.checkTaskDescription());

        Task longTask = new Task("LongTaskName", "This is a very long task description that exceeds 50 characters", "Developer", 10, 1);
        assertFalse(longTask.checkTaskDescription());
    }

    @Test
    public void testCreateTaskID() {
        Task task = new Task("TaskName", "Short description", "Developer", 10, 1);
        assertEquals("TA:1:PER", task.getTaskID());

        Task longTask = new Task("LongTaskName", "Short description", "LongDeveloperName", 10, 1);
        assertEquals("LO:1:AME", longTask.getTaskID());
    }

    @Test
    public void testPrintTaskDetails() {
        Task task = new Task("TaskName", "Short description", "Developer", 10, 1);
        task.setTaskStatus("InProgress");
        assertEquals("Task Status: InProgress\n" +
                     "Developer Details: Developer\n" +
                     "Task Number: 1\n" +
                     "Task Name: TaskName\n" +
                     "Task Description: Short description\n" +
                     "Task ID: TA:1:PER\n" +
                     "Task Duration: 10 hours", task.printTaskDetails());
    }

    @Test
    public void testDeveloperArrayPopulation() {
        String[] expectedDevelopers = {"Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"};
        ArrayList<String> developers = new ArrayList<>();
        developers.add("Mike Smith");
        developers.add("Edward Harrison");
        developers.add("Samantha Paulson");
        developers.add("Glenda Oberholzer");

        assertArrayEquals(expectedDevelopers, developers.toArray());
    }

    @Test
    public void testLongestTaskDuration() {
        ArrayList<Integer> taskDurations = new ArrayList<>();
        taskDurations.add(5);
        taskDurations.add(8);
        taskDurations.add(2);
        taskDurations.add(11);

        int maxDuration = 0;
        int index = -1;
        for (int i = 0; i < taskDurations.size(); i++) {
            if (taskDurations.get(i) > maxDuration) {
                maxDuration = taskDurations.get(i);
                index = i;
            }
        }

        assertEquals(11, maxDuration);
    }

    @Test
    public void testSearchTaskByName() {
        Task task = new Task("Create Login", "Short description", "Mike Smith", 5, 1);
        assertEquals("Mike Smith", task.getDeveloperDetails());
        assertEquals("Create Login", task.getTaskName());
    }

    @Test
    public void testSearchTasksByDeveloper() {
        ArrayList<Task> tasks = new ArrayList<>();
        Task task = new Task("Create Reports", "Short description", "Samantha Paulson", 2, 1);
        task.setTaskStatus("Done");
        tasks.add(task);

        StringBuilder result = new StringBuilder();
        for (Task t : tasks) {
            if (t.getDeveloperDetails().equalsIgnoreCase("Samantha Paulson")) {
                result.append(t.getTaskName()).append(", ").append(t.getTaskStatus());
            }
        }

        assertEquals("Create Reports, Done", result.toString());
    }

    @Test
    public void testDeleteTaskByName() {
        ArrayList<Task> tasks = new ArrayList<>();
        Task task = new Task("Create Reports", "Short description", "Samantha Paulson", 2, 1);
        tasks.add(task);

        tasks.removeIf(t -> t.getTaskName().equalsIgnoreCase("Create Reports"));

        assertTrue(tasks.isEmpty());
    }

    @Test
    public void testDisplayReport() {
        Task task = new Task("Create Login", "Short description", "Mike Smith", 5, 1);
        task.setTaskStatus("To Do");

        String expectedReport = "Task Status: To Do\n" +
                "Developer Details: Mike Smith\n" +
                "Task Number: 1\n" +
                "Task Name: Create Login\n" +
                "Task Description: Short description\n" +
                "Task ID: CR:1:ITH\n" +
                "Task Duration: 5 hours\n\n";

        assertEquals(expectedReport, task.printTaskDetails() + "\n\n");
    }
}

//Reference For Unit Testing:
//https://youtu.be/sFTbCVnUbLo?si=FELc6DZBSnYEnnD6